import ActivityKit
import Foundation

enum EyeMode: String, Codable, Hashable, CaseIterable, Identifiable {
    case classic, mangekyo, itachi, sasuke, madara, obito, rinnegan, byakugan, demon, cyber, closed, flame, moon, orbit, constellation, skull, energy, robot
    var id: String { rawValue }
    var title: String {
        switch self {
        case .classic: return "Sharingan"
        case .mangekyo: return "Mangekyō"
        case .itachi: return "Itachi"
        case .sasuke: return "Sasuke"
        case .madara: return "Madara"
        case .obito: return "Obito"
        case .rinnegan: return "Rinnegan"
        case .byakugan: return "Byakugan"
        case .demon: return "Olho demoníaco"
        case .cyber: return "Olho cyber"
        case .closed: return "Fechado"
        case .flame: return "Chama"
        case .moon: return "Lua"
        case .orbit: return "Órbita"
        case .constellation: return "Constelação"
        case .skull: return "Crânio"
        case .energy: return "Energia"
        case .robot: return "Robô"
        }
    }
    var next: Self { let all = Self.allCases; return all[((all.firstIndex(of: self) ?? 0) + 1) % all.count] }
    var evolved: Self {
        switch self {
        case .classic, .closed: return .mangekyo
        case .mangekyo: return .itachi
        case .itachi: return .sasuke
        case .sasuke: return .madara
        case .madara: return .rinnegan
        case .obito: return .rinnegan
        default: return .classic
        }
    }
    var symbol: String? {
        switch self {
        case .flame: return "flame.fill"
        case .moon: return "moon.stars.fill"
        case .orbit: return "atom"
        case .constellation: return "sparkles"
        case .skull: return "skull"
        case .energy: return "bolt.fill"
        case .robot: return "eye.circle.fill"
        default: return nil
        }
    }
}
enum EyeSide: String, Codable, Hashable, CaseIterable, Identifiable {
    case left, right, both
    var id: String { rawValue }
    var title: String { switch self { case .left: return "Esquerda"; case .right: return "Direita"; case .both: return "Ambos" } }
}
enum EyeSize: Int, Codable, Hashable, CaseIterable, Identifiable {
    case small = 16, medium = 22, large = 30
    var id: Int { rawValue }
    var title: String { switch self { case .small: return "P"; case .medium: return "M"; case .large: return "G" } }
    var points: Double { Double(rawValue) }
}
enum EyeColor: String, Codable, Hashable, CaseIterable, Identifiable {
    case original, red, purple, cyan, gold, white, green
    var id: String { rawValue }
    var title: String { switch self { case .original: return "Original"; case .red: return "Vermelho"; case .purple: return "Violeta"; case .cyan: return "Ciano"; case .gold: return "Dourado"; case .white: return "Branco"; case .green: return "Verde" } }
}
enum Effect: String, Codable, Hashable, CaseIterable, Identifiable {
    case rotate, pulse, blink, glow, flash, shake, fade, transform
    var id: String { rawValue }
    var title: String { switch self { case .rotate: return "Rotação"; case .pulse: return "Pulsação"; case .blink: return "Abrir / fechar"; case .glow: return "Aura luminosa"; case .flash: return "Flash suave"; case .shake: return "Oscilação"; case .fade: return "Aparecer / desaparecer"; case .transform: return "Transformação" } }
}
enum EffectSpeed: String, Codable, Hashable, CaseIterable, Identifiable {
    case fast, normal, slow
    var id: String { rawValue }
    var title: String { switch self { case .fast: return "Rápida"; case .normal: return "Normal"; case .slow: return "Lenta" } }
    var duration: Double { switch self { case .fast: return 0.25; case .normal: return 0.48; case .slow: return 0.85 } }
}
enum EyePreset: String, CaseIterable, Identifiable {
    case discreet = "Discreto", anime = "Anime", premium = "Premium", cyber = "Cyber", minimal = "Minimalista"
    var id: String { rawValue }
    var config: EyeConfig {
        var c = EyeConfig()
        switch self {
        case .discreet: break
        case .anime: c.effects = [.rotate,.pulse,.transform,.glow]; c.size = .large
        case .premium: c.effects = [.pulse,.glow,.fade]; c.color = .gold; c.mode = .orbit
        case .cyber: c.effects = [.rotate,.flash,.glow]; c.color = .cyan; c.mode = .cyber
        case .minimal: c.effects = []; c.size = .small; c.color = .white; c.mode = .moon
        }
        return c
    }
}
struct EyeConfig: Codable, Hashable {
    var mode: EyeMode = .classic
    var side: EyeSide = .left
    var size: EyeSize = .medium
    var color: EyeColor = .original
    var intensity: Double = 0.85
    var effects: Set<Effect> = [.pulse]
    var speed: EffectSpeed = .normal
    var animateOnStart = true
    var oppositeDot = false
    var expandedFocus = true
    var autoPreview = false
    static let storageKey = "eyeConfigV2"
    static func load() -> Self {
        if let data = UserDefaults.standard.data(forKey: storageKey), let decoded = try? JSONDecoder().decode(Self.self, from: data) { return decoded }
        var config = Self()
        if let old = UserDefaults.standard.string(forKey: "preferredEye"), let mode = EyeMode(rawValue: old) { config.mode = mode }
        return config
    }
    func save() { if let data = try? JSONEncoder().encode(self) { UserDefaults.standard.set(data, forKey: Self.storageKey) } }
}
struct EyeAttributes: ActivityAttributes {
    struct ContentState: Codable, Hashable {
        var config: EyeConfig
        var phase: Bool = false
        var turn: Int = 0
        var revision: Int = 0
    }
    let startedAt: Date
}
