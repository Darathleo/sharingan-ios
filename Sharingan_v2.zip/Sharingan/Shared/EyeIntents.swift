import ActivityKit
import AppIntents
import Foundation

@MainActor enum EyeSession {
    static var active: Activity<EyeAttributes>? { Activity<EyeAttributes>.activities.first { $0.activityState == .active || $0.activityState == .stale } }
    static func update(_ c: EyeConfig, on a: Activity<EyeAttributes>) async {
        var s = a.content.state; s.config = c; s.phase = false; s.revision += 1
        if c.effects.contains(.rotate) { s.turn += 1 }
        await a.update(ActivityContent(state: s, staleDate: nil)); c.save()
    }
    static func play(on a: Activity<EyeAttributes>) async {
        var s = a.content.state
        guard !s.config.effects.isEmpty else { return }
        s.phase = true; s.revision += 1
        if s.config.effects.contains(.rotate) { s.turn += 1 }
        if s.config.effects.contains(.transform) { s.config.mode = s.config.mode.evolved }
        let revision = s.revision
        await a.update(ActivityContent(state: s, staleDate: nil))
        s.config.save()
        try? await Task.sleep(nanoseconds: UInt64((s.config.speed.duration + 0.08)*1_000_000_000))
        var current = a.content.state
        guard current.revision == revision, a.activityState == .active || a.activityState == .stale else { return }
        current.phase = false; current.revision += 1
        await a.update(ActivityContent(state: current, staleDate: nil))
    }
    static func stop() async { for a in Activity<EyeAttributes>.activities { await a.end(nil, dismissalPolicy: .immediate) } }
}
struct ChangeEyeIntent: LiveActivityIntent {
    static var title: LocalizedStringResource = "Alternar figura"
    static var openAppWhenRun: Bool = false
    @MainActor func perform() async throws -> some IntentResult {
        if let a = EyeSession.active { var c = a.content.state.config; c.mode = c.mode.next; await EyeSession.update(c, on: a) }
        return .result()
    }
}
struct PlayEyeIntent: LiveActivityIntent {
    static var title: LocalizedStringResource = "Executar efeitos"
    static var openAppWhenRun: Bool = false
    @MainActor func perform() async throws -> some IntentResult { if let a = EyeSession.active { await EyeSession.play(on: a) }; return .result() }
}
struct EvolveEyeIntent: LiveActivityIntent {
    static var title: LocalizedStringResource = "Transformar figura"
    static var openAppWhenRun: Bool = false
    @MainActor func perform() async throws -> some IntentResult {
        if let a = EyeSession.active { var c = a.content.state.config; c.mode = c.mode.evolved; await EyeSession.update(c, on: a) }; return .result()
    }
}
struct EndEyeIntent: LiveActivityIntent {
    static var title: LocalizedStringResource = "Desativar Sharingan"
    static var openAppWhenRun: Bool = false
    @MainActor func perform() async throws -> some IntentResult { await EyeSession.stop(); return .result() }
}
