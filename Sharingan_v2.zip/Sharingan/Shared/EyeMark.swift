import SwiftUI

extension EyeColor {
    func tint(for mode: EyeMode) -> Color {
        switch self {
        case .red: return Color(red: 0.91, green: 0.08, blue: 0.19)
        case .purple: return Color(red: 0.66, green: 0.35, blue: 1)
        case .cyan: return .cyan
        case .gold: return Color(red: 1, green: 0.72, blue: 0.25)
        case .white: return Color(white: 0.9)
        case .green: return .green
        case .original:
            switch mode {
            case .rinnegan: return EyeColor.purple.tint(for: mode)
            case .byakugan: return EyeColor.white.tint(for: mode)
            case .cyber, .robot, .orbit, .constellation: return .cyan
            case .flame, .energy: return .orange
            default: return EyeColor.red.tint(for: mode)
            }
        }
    }
}
struct EyeMark: View {
    let config: EyeConfig
    private var tint: Color { config.color.tint(for: config.mode) }
    var body: some View {
        ZStack {
            if let symbol = config.mode.symbol, config.mode != .skull {
                Image(systemName: symbol).resizable().scaledToFit().foregroundStyle(tint).padding(2)
            } else {
                Canvas { ctx, size in
                    let d = min(size.width, size.height)
                    guard d > 0 else { return }
                    let ox = (size.width-d)/2, oy = (size.height-d)/2
                    func p(_ x: CGFloat, _ y: CGFloat) -> CGPoint { CGPoint(x: ox+x*d,y: oy+y*d) }
                    func disc(_ x: CGFloat,_ y: CGFloat,_ r: CGFloat) -> Path { Path(ellipseIn: CGRect(x: p(x-r,y-r).x,y: p(x-r,y-r).y,width: 2*r*d,height: 2*r*d)) }
                    let ink = Color.black
                    if config.mode == .closed {
                        var lid = Path(); lid.move(to: p(0.06,0.44)); lid.addQuadCurve(to: p(0.94,0.44),control: p(0.5,0.8))
                        ctx.stroke(lid,with: .color(tint),style: StrokeStyle(lineWidth: d*0.075,lineCap: .round)); return
                    }
                    if config.mode == .skull {
                        ctx.fill(disc(0.5,0.39,0.34),with: .color(tint))
                        ctx.fill(Path(roundedRect: CGRect(x: p(0.31,0.55).x,y: p(0.31,0.55).y,width: d*0.38,height: d*0.31),cornerRadius: d*0.05),with: .color(tint))
                        for x in [CGFloat(0.36),0.64] { ctx.fill(disc(x,0.42,0.10),with: .color(ink)) }
                        ctx.fill(disc(0.5,0.60,0.047),with: .color(ink))
                        for x in [CGFloat(0.42),0.58] { var line = Path(); line.move(to: p(x,0.70)); line.addLine(to: p(x,0.86)); ctx.stroke(line,with: .color(ink),lineWidth: d*0.035) }
                        return
                    }
                    let iris = disc(0.5,0.5,0.45)
                    ctx.fill(iris,with: .radialGradient(Gradient(colors: [tint,tint.opacity(0.9),tint.opacity(0.50)]),center: p(0.5,0.5),startRadius: 0,endRadius: d*0.45))
                    ctx.stroke(iris,with: .color(tint),lineWidth: d*0.035)
                    switch config.mode {
                    case .rinnegan:
                        for r in [CGFloat(0.12),0.22,0.32,0.41] { ctx.stroke(disc(0.5,0.5,r),with: .color(ink),lineWidth: d*0.025) }
                    case .byakugan:
                        ctx.stroke(disc(0.5,0.5,0.22),with: .color(.gray.opacity(0.65)),lineWidth: d*0.025)
                        return
                    case .demon:
                        ctx.fill(Path(ellipseIn: CGRect(x: p(0.43,0.13).x,y: p(0.43,0.13).y,width: d*0.14,height: d*0.74)),with: .color(ink)); return
                    case .cyber:
                        for r in [CGFloat(0.16),0.32] { ctx.stroke(disc(0.5,0.5,r),with: .color(ink),style: StrokeStyle(lineWidth: d*0.05,dash:[d*0.11,d*0.035])) }
                    default:
                        ctx.stroke(disc(0.5,0.5,0.29),with: .color(ink.opacity(0.8)),lineWidth: d*0.025)
                        let n = config.mode == .sasuke ? 6 : config.mode == .madara ? 4 : 3
                        for i in 0..<n {
                            let a = Double(i)*2*Double.pi/Double(n)-Double.pi/2
                            func q(_ x: CGFloat,_ y: CGFloat) -> CGPoint { let c = CGFloat(cos(a)),s = CGFloat(sin(a)); return p(0.5+x*c-y*s,0.5+x*s+y*c) }
                            var blade = Path()
                            switch config.mode {
                            case .classic:
                                let c = q(0.29,0); ctx.fill(Path(ellipseIn: CGRect(x: c.x-d*0.071,y: c.y-d*0.071,width: d*0.142,height: d*0.142)),with: .color(ink))
                                blade.move(to: q(0.29,-0.055)); blade.addQuadCurve(to: q(0.33,0.115),control: q(0.43,0.015)); blade.addQuadCurve(to: q(0.25,0.05),control: q(0.30,0.045))
                            case .itachi:
                                blade.move(to: q(0.44,-0.07)); blade.addQuadCurve(to: q(0.04,0.09),control: q(0.36,0.24)); blade.addQuadCurve(to: q(0.12,-0.10),control: q(0.015,-0.01))
                            case .sasuke:
                                blade.move(to: q(0.42,0)); blade.addLine(to: q(0.16,0.09)); blade.addLine(to: q(0.05,0)); blade.addLine(to: q(0.16,-0.09))
                            case .madara:
                                blade.move(to: q(0.42,-0.09)); blade.addLine(to: q(0.42,0.09)); blade.addLine(to: q(0.13,0.15)); blade.addLine(to: q(0.13,-0.15))
                            case .obito:
                                blade.move(to: q(0.43,0)); blade.addQuadCurve(to: q(0.05,0.12),control: q(0.29,0.24)); blade.addLine(to: q(0.16,-0.13))
                            default:
                                blade.move(to: q(0.43,0)); blade.addQuadCurve(to: q(0.08,0.15),control: q(0.36,0.26)); blade.addQuadCurve(to: q(0.10,-0.04),control: q(0.025,0.06)); blade.addQuadCurve(to: q(0.43,0),control: q(0.28,0.08))
                            }
                            blade.closeSubpath(); ctx.fill(blade,with: .color(ink))
                        }
                    }
                    ctx.fill(disc(0.5,0.5,0.10),with: .color(ink))
                }
            }
        }.aspectRatio(1, contentMode: .fit).opacity(config.intensity).accessibilityLabel(config.mode.title)
    }
}
struct AnimatedEye: View {
    let state: EyeAttributes.ContentState
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    var body: some View {
        let c = state.config
        let e = c.effects
        let p = state.phase && !reduceMotion
        let tint = c.color.tint(for: c.mode)
        EyeMark(config: c)
            .id(c.mode)
            .transition(e.contains(.transform) && !reduceMotion ? .scale(scale: 0.55).combined(with: .opacity) : .identity)
            .rotationEffect(.degrees(e.contains(.rotate) && !reduceMotion ? Double(state.turn)*360 : 0))
            .scaleEffect(p && e.contains(.pulse) ? 0.72 : 1)
            .scaleEffect(x: 1, y: p && e.contains(.blink) ? 0.08 : 1)
            .offset(x: p && e.contains(.shake) ? 2 : 0)
            .opacity(p && e.contains(.fade) ? 0.18 : 1)
            .overlay { if p && e.contains(.flash) { Circle().fill(.white.opacity(0.22)).padding(2).allowsHitTesting(false) } }
            .shadow(color: e.contains(.glow) ? tint.opacity(p ? 0.9 : 0.45) : .clear, radius: p ? 4 : 2)
            .animation(reduceMotion ? nil : .easeInOut(duration: c.speed.duration), value: state)
    }
}
