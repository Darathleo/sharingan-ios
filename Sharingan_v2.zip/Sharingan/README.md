# Sharingan 2.0 — Dynamic Island Studio

Projeto experimental iOS 17+, atualizado a partir da V1 compilada com sucesso. Os bundle IDs, o esquema, a extensão e o ícone foram preservados. Versão 2.0, build 2.

## Recursos
18 figuras, incluindo interpretações vetoriais de dōjutsus e símbolos; 8 efeitos independentes, 3 velocidades, 7 opções de cor, intensidade, 3 tamanhos, esquerda/direita/ambos, ponto oposto opcional, destaque expandido, 5 presets, prévia animada no app, quatro controles expandidos e quatro App Shortcuts. Piscar está desativado por padrão.

## Limitações
A Apple define a forma e largura da ilha. O lado não selecionado recebe conteúdo transparente, não uma alteração do sistema. Os efeitos da Live Activity tentam animar mudanças de estado; o sistema pode agrupar, limitar ou ignorar animações e atualizações. O loop de prévia só roda dentro do app em primeiro plano. Não existe loop garantido em segundo plano, transformação automática ao manter pressionado, nem expansão unilateral forçada. O botão Transformar está disponível na ilha expandida. O desenho de cada olho é estilizado. Atalhos e automações pessoais devem ser testados no aparelho, inclusive disparo em segundo plano e permissões. Não há serviço externo.

## Atualização
Desative a sessão da V1 antes de atualizar. Envie Sharingan_iOS_V2.zip para a raiz do repositório. Crie .github/workflows/build-sharingan-v2.yml com o YAML fornecido. Execute Build Sharingan V2 IPA e baixe Sharingan-V2-IPA. Extraia Sharingan-V2.ipa. Instale pelo Sideloadly com a mesma conta e o mesmo Bundle ID usado na V1, preservando a extensão. A versão V1 continua disponível no artefato anterior. Não apague a V1 antes de confirmar a V2. Se necessário, reinstale a V1; a preservação dos dados não é garantida em um downgrade.

## Testes recomendados
1. Compile e confirme o IPA e o plug-in SharinganWidget.appex.
2. Abra o app, teste todas as figuras na prévia; escolha esquerda e ponto oposto desativado.
3. Ative, saia do app, teste esquerda/direita/ambos, tamanhos e cores.
4. Pressione a ilha; teste alternar, executar efeitos, transformar e encerrar.
5. Teste cada efeito isoladamente em velocidade normal. Confira que piscar desligado mantém o símbolo aberto, exceto se o usuário escolher a figura Fechado.
6. Teste Atalhos, encerramento/reinício e preferências persistentes. O iOS pode limitar efeitos.

Validação local: parsing Swift e estrutura dos arquivos. Compilação Xcode e teste em aparelho ainda pendentes.
