import SwiftUI
import WidgetKit
import ActivityKit
import AppIntents

@main struct EyeWidget: Widget {
    var body: some WidgetConfiguration {
        ActivityConfiguration(for: EyeAttributes.self) { context in
            HStack(spacing: 12) {
                AnimatedEye(state: context.state).frame(width: 36, height: 36)
                VStack(alignment: .leading, spacing: 3) {
                    Text(context.state.config.mode.title).font(.headline)
                    Text("Sessão visual ativa").font(.caption).foregroundStyle(.secondary)
                }
                Spacer(minLength: 2)
                controls
            }.padding(14).activityBackgroundTint(.black).activitySystemActionForegroundColor(.white).foregroundStyle(.white)
        } dynamicIsland: { context in
            let c = context.state.config
            return DynamicIsland {
                DynamicIslandExpandedRegion(.leading) {
                    if c.side != .right { AnimatedEye(state: context.state).frame(width: c.expandedFocus ? 40 : 28,height: c.expandedFocus ? 40 : 28) }
                }
                DynamicIslandExpandedRegion(.trailing) {
                    if c.side != .left { AnimatedEye(state: context.state).frame(width: c.expandedFocus ? 40 : 28,height: c.expandedFocus ? 40 : 28) }
                }
                DynamicIslandExpandedRegion(.bottom) {
                    HStack(spacing: 6) {
                        if c.side == .right { controls; Spacer(minLength: 3); Text(c.mode.title).font(.caption.weight(.semibold)).lineLimit(1) }
                        else { Text(c.mode.title).font(.caption.weight(.semibold)).lineLimit(1); Spacer(minLength: 3); controls }
                    }.padding(.horizontal, 8).padding(.bottom, 4)
                }
            } compactLeading: {
                compact(context.state, visible: c.side != .right)
            } compactTrailing: {
                compact(context.state, visible: c.side != .left)
            } minimal: {
                AnimatedEye(state: context.state).frame(width: min(c.size.points, 22),height: min(c.size.points,22))
            }
        }
    }
    @ViewBuilder private func compact(_ state: EyeAttributes.ContentState, visible: Bool) -> some View {
        if visible { AnimatedEye(state: state).frame(width: state.config.size.points,height: state.config.size.points) }
        else if state.config.oppositeDot { Circle().fill(state.config.color.tint(for: state.config.mode)).frame(width: 5,height: 5).accessibilityHidden(true) }
        else { Color.clear.frame(width: 1,height: 1).accessibilityHidden(true) }
    }
    private func icon(_ name: String) -> some View { Image(systemName: name).font(.system(size: 13,weight: .semibold)).frame(width: 33,height: 33).background(.white.opacity(0.12),in: Circle()) }
    private var controls: some View {
        HStack(spacing: 4) {
            Button(intent: ChangeEyeIntent()) { icon("arrow.triangle.2.circlepath") }.accessibilityLabel("Alternar figura")
            Button(intent: PlayEyeIntent()) { icon("play.fill") }.accessibilityLabel("Executar efeitos")
            Button(intent: EvolveEyeIntent()) { icon("sparkles") }.accessibilityLabel("Transformar figura")
            Button(intent: EndEyeIntent()) { icon("power") }.accessibilityLabel("Encerrar sessão")
        }.buttonStyle(.plain).foregroundStyle(.white)
    }
}
