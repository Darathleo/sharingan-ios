import SwiftUI
import ActivityKit
import AppIntents

extension EyeSession {
    static func start(_ c: EyeConfig) throws -> Activity<EyeAttributes> {
        if let active { return active }
        return try Activity.request(attributes: EyeAttributes(startedAt: .now), content: ActivityContent(state: .init(config: c), staleDate: nil), pushType: nil)
    }
}
struct StartEyeIntent: LiveActivityIntent {
    static var title: LocalizedStringResource = "Ativar Sharingan"
    static var openAppWhenRun: Bool = false
    @MainActor func perform() async throws -> some IntentResult {
        let c = EyeConfig.load(); let a = try EyeSession.start(c)
        if c.animateOnStart { await EyeSession.play(on: a) }; return .result()
    }
}
struct SharinganShortcuts: AppShortcutsProvider {
    static var appShortcuts: [AppShortcut] {
        AppShortcut(intent: StartEyeIntent(), phrases: ["Ativar \(.applicationName)"],shortTitle: "Ativar",systemImageName: "eye")
        AppShortcut(intent: EndEyeIntent(), phrases: ["Desativar \(.applicationName)"],shortTitle: "Desativar",systemImageName: "power")
        AppShortcut(intent: PlayEyeIntent(), phrases: ["Animar \(.applicationName)"],shortTitle: "Animar",systemImageName: "play.fill")
        AppShortcut(intent: EvolveEyeIntent(), phrases: ["Transformar \(.applicationName)"],shortTitle: "Transformar",systemImageName: "sparkles")
    }
}
struct ContentView: View {
    @Environment(\.scenePhase) private var scenePhase
    @State private var config = EyeConfig.load()
    @State private var activity: Activity<EyeAttributes>?
    @State private var preview = EyeAttributes.ContentState(config: EyeConfig.load())
    @State private var busy = false
    @State private var error: String?
    private var tint: Color { config.color.tint(for: config.mode) }
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading,spacing: 22) {
                    header
                    section("Biblioteca • 18 figuras") {
                        LazyVGrid(columns: Array(repeating: GridItem(.flexible(),spacing: 8),count: 3),spacing: 8) {
                            ForEach(EyeMode.allCases) { mode in
                                Button { var c = config; c.mode = mode; apply(c) } label: {
                                    VStack(spacing: 8) {
                                        EyeMark(config: figure(mode)).frame(width: 36,height: 36)
                                        Text(mode.title).font(.caption2).lineLimit(1).minimumScaleFactor(0.65)
                                    }.frame(maxWidth: .infinity).padding(.vertical,12).background(.white.opacity(0.045),in: RoundedRectangle(cornerRadius: 12)).overlay(RoundedRectangle(cornerRadius: 12).strokeBorder(mode == config.mode ? tint : .white.opacity(0.08)))
                                }.buttonStyle(.plain)
                            }
                        }
                    }
                    section("Layout da ilha") {
                        Picker("Posição",selection: binding(\.side)) { ForEach(EyeSide.allCases) { Text($0.title).tag($0) } }.pickerStyle(.segmented)
                        HStack { Text("Tamanho"); Spacer(); Picker("Tamanho",selection: binding(\.size)) { ForEach(EyeSize.allCases) { Text($0.title).tag($0) } }.pickerStyle(.segmented).frame(width: 150) }
                        Toggle("Ponto no lado oposto",isOn: binding(\.oppositeDot))
                        Toggle("Destaque no modo expandido",isOn: binding(\.expandedFocus))
                        Text("O iOS define a largura e o formato da ilha. O lado vazio não garante redução física.").font(.caption).foregroundStyle(.secondary)
                    }
                    section("Aparência") {
                        Picker("Cor",selection: binding(\.color)) { ForEach(EyeColor.allCases) { Text($0.title).tag($0) } }
                        HStack { Text("Intensidade"); Spacer(); Text("\(Int(config.intensity*100))%").monospacedDigit() }
                        Slider(value: Binding(get: { config.intensity },set: { v in var c = config; c.intensity = v; config = c; preview.config = c; c.save() }),in: 0.25...1,onEditingChanged: { editing in if !editing { apply(config) } })
                    }
                    section("Efeitos e animações") {
                        ForEach(Effect.allCases) { effect in
                            Toggle(effect.title,isOn: Binding(get: { config.effects.contains(effect) },set: { enabled in var c = config; if enabled { c.effects.insert(effect) } else { c.effects.remove(effect) }; apply(c) }))
                        }
                        Picker("Velocidade",selection: binding(\.speed)) { ForEach(EffectSpeed.allCases) { Text($0.title).tag($0) } }
                        Toggle("Efeito ao ativar",isOn: binding(\.animateOnStart))
                        Toggle("Repetir somente na prévia",isOn: binding(\.autoPreview))
                        Text("Na Dynamic Island, os efeitos são tentativas de transição por atualização, não um loop. Pressione a ilha para executar ou transformar.").font(.caption).foregroundStyle(.secondary)
                        HStack {
                            Button { Task { await play() } } label: { Label("Animar",systemImage: "play.fill") }.buttonStyle(.borderedProminent)
                            Button { var c = config; c.mode = c.mode.evolved; apply(c) } label: { Label("Transformar",systemImage: "sparkles") }.buttonStyle(.bordered)
                        }
                    }
                    section("Presets") {
                        ScrollView(.horizontal,showsIndicators: false) { HStack { ForEach(EyePreset.allCases) { preset in Button(preset.rawValue) { apply(preset.config) }.buttonStyle(.bordered) } } }
                    }
                    section("Atalhos e automações") {
                        Text("No app Atalhos, procure Sharingan: Ativar, Desativar, Animar e Transformar. Use automações pessoais, como nível de bateria ou modo Foco, para disparar esses comandos. A execução depende das permissões do iOS.").font(.footnote).foregroundStyle(.secondary)
                    }
                }.padding(20).frame(maxWidth: 520).frame(maxWidth: .infinity)
            }.navigationTitle("Sharingan 2.0").navigationBarTitleDisplayMode(.inline)
            .background(Color(red: 0.045,green: 0.045,blue: 0.055).ignoresSafeArea())
            .tint(tint).disabled(busy)
        }
        .onAppear { refresh() }
        .onChange(of: scenePhase) { _, phase in if phase == .active { refresh() } }
        .task(id: activity?.id) {
            guard let a = activity else { return }
            for await content in a.contentUpdates { guard activity?.id == a.id else { break }; config = content.state.config; preview = content.state; config.save() }
        }
        .task(id: activity?.id) {
            guard let a = activity else { return }
            for await state in a.activityStateUpdates { if state == .ended || state == .dismissed { refresh(); break } }
        }
        .task(id: config.autoPreview && scenePhase == .active) {
            guard config.autoPreview, scenePhase == .active else { return }
            while !Task.isCancelled {
                try? await Task.sleep(nanoseconds: 2_400_000_000)
                if Task.isCancelled { break }
                if !busy { await animatePreview() }
            }
        }
    }
    private var header: some View {
        VStack(spacing: 13) {
            Text("DYNAMIC ISLAND STUDIO").font(.caption2.monospaced().weight(.semibold)).tracking(3).foregroundStyle(tint)
            HStack(spacing: 8) {
                if config.side != .right { AnimatedEye(state: preview).frame(width: config.size.points,height: config.size.points) }
                else if config.oppositeDot { Circle().fill(tint).frame(width: 5,height: 5) }
                Capsule().fill(.black).frame(width: 105,height: 30)
                if config.side != .left { AnimatedEye(state: preview).frame(width: config.size.points,height: config.size.points) }
                else if config.oppositeDot { Circle().fill(tint).frame(width: 5,height: 5) }
            }.padding(.horizontal,9).frame(height: 40).background(.black,in: Capsule()).overlay(Capsule().strokeBorder(.white.opacity(0.10)))
            AnimatedEye(state: preview).frame(width: 96,height: 96).padding(10)
            Text(config.mode.title).font(.title2.weight(.semibold))
            Text(activity == nil ? "Sessão inativa" : "Sessão ativa").font(.caption).foregroundStyle(.secondary)
            Button { Task { await toggleSession() } } label: { Text(activity == nil ? "Ativar Sharingan" : "Desativar Sharingan").font(.headline).frame(maxWidth: .infinity).padding(14).background(activity == nil ? tint : Color.white.opacity(0.10),in: RoundedRectangle(cornerRadius: 13)).foregroundStyle(.white) }.buttonStyle(.plain)
            if let error { Text(error).font(.footnote).foregroundStyle(.orange) }
        }.frame(maxWidth: .infinity)
    }
    private func section<Content: View>(_ title: String,@ViewBuilder content: () -> Content) -> some View {
        VStack(alignment: .leading,spacing: 12) { Text(title).font(.headline); content() }.padding(14).frame(maxWidth: .infinity,alignment: .leading).background(.white.opacity(0.035),in: RoundedRectangle(cornerRadius: 17))
    }
    private func figure(_ mode: EyeMode) -> EyeConfig { var c = config; c.mode = mode; c.color = .original; return c }
    private func binding<T>(_ key: WritableKeyPath<EyeConfig,T>) -> Binding<T> { Binding(get: { config[keyPath: key] },set: { v in var c = config; c[keyPath: key] = v; apply(c) }) }
    @MainActor private func refresh() { activity = EyeSession.active; config = activity?.content.state.config ?? EyeConfig.load(); preview = activity?.content.state ?? .init(config: config) }
    @MainActor private func apply(_ c: EyeConfig) {
        guard !busy else { return }; config = c; c.save(); preview.config = c; preview.phase = false
        if c.effects.contains(.rotate) { preview.turn += 1 }; preview.revision += 1
        if let a = activity { busy = true; Task { await EyeSession.update(c,on: a); busy = false } }
    }
    @MainActor private func animatePreview() async {
        preview.config = config; preview.phase = true; preview.revision += 1
        if config.effects.contains(.rotate) { preview.turn += 1 }
        if config.effects.contains(.transform) { preview.config.mode = config.mode.evolved }
        try? await Task.sleep(nanoseconds: UInt64((config.speed.duration+0.08)*1_000_000_000))
        preview.phase = false; preview.revision += 1
    }
    @MainActor private func play() async {
        guard !busy else { return }; busy = true; defer { busy = false }
        if let a = activity { await EyeSession.play(on: a); refresh() } else { await animatePreview() }
    }
    @MainActor private func toggleSession() async {
        guard !busy else { return }; busy = true; defer { busy = false }; error = nil
        if activity != nil { await EyeSession.stop(); refresh(); return }
        guard ActivityAuthorizationInfo().areActivitiesEnabled else { error = "Ative as Atividades ao Vivo nos Ajustes."; return }
        do { let a = try EyeSession.start(config); activity = a; if config.animateOnStart { await EyeSession.play(on: a) }; refresh() }
        catch { self.error = error.localizedDescription }
    }
}
