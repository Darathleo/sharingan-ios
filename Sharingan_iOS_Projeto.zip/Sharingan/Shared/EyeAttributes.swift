import ActivityKit
import Foundation

enum EyeMode: String, Codable, Hashable, CaseIterable, Identifiable {
    case classic, mangekyo, closed
    var id: String { rawValue }
    var title: String {
        switch self {
        case .classic: return "Sharingan"
        case .mangekyo: return "Mangekyō"
        case .closed: return "Fechado"
        }
    }
    var next: Self {
        switch self {
        case .classic: return .mangekyo
        case .mangekyo: return .closed
        case .closed: return .classic
        }
    }
}

struct EyeAttributes: ActivityAttributes {
    struct ContentState: Codable, Hashable {
        var mode: EyeMode
    }
    let startedAt: Date
}
