import SwiftUI

/// A vector symbol, not a video or a continuously animated view.
struct EyeMark: View {
    let mode: EyeMode
    private let crimson = Color(red: 0.84, green: 0.06, blue: 0.16)

    var body: some View {
        Canvas { context, size in
            let d = min(size.width, size.height)
            guard d > 0 else { return }
            let origin = CGPoint(x: (size.width-d)/2, y: (size.height-d)/2)
            func p(_ x: CGFloat, _ y: CGFloat) -> CGPoint {
                CGPoint(x: origin.x + x*d, y: origin.y + y*d)
            }
            func disc(_ x: CGFloat, _ y: CGFloat, _ r: CGFloat) -> Path {
                Path(ellipseIn: CGRect(x: p(x-r,y-r).x, y: p(x-r,y-r).y, width: 2*r*d, height: 2*r*d))
            }
            if mode == .closed {
                var lid = Path()
                lid.move(to: p(0.07,0.46))
                lid.addQuadCurve(to: p(0.93,0.46), control: p(0.5,0.80))
                context.stroke(lid, with: .color(crimson), style: StrokeStyle(lineWidth: d*0.075, lineCap: .round))
                return
            }
            let iris = disc(0.5,0.5,0.45)
            context.fill(iris, with: .radialGradient(Gradient(colors: [Color(red: 1, green: 0.20, blue: 0.24), crimson, Color(red: 0.43, green: 0.005, blue: 0.04)]), center: p(0.5,0.5), startRadius: 0, endRadius: d*0.46))
            context.stroke(iris, with: .color(crimson), lineWidth: d*0.035)
            context.stroke(disc(0.5,0.5,0.29), with: .color(.black.opacity(0.75)), lineWidth: d*0.027)
            for i in 0..<3 {
                let angle = Double(i)*2*Double.pi/3 - Double.pi/2
                func q(_ x: CGFloat, _ y: CGFloat) -> CGPoint {
                    let c = CGFloat(cos(angle)), s = CGFloat(sin(angle))
                    return p(0.5+x*c-y*s, 0.5+x*s+y*c)
                }
                var blade = Path()
                if mode == .classic {
                    blade.move(to: q(0.29,-0.055))
                    blade.addQuadCurve(to: q(0.33,0.115), control: q(0.43,0.015))
                    blade.addQuadCurve(to: q(0.25,0.05), control: q(0.30,0.045))
                    blade.closeSubpath()
                    let center = CGPoint(x: 0.5+0.29*CGFloat(cos(angle)), y: 0.5+0.29*CGFloat(sin(angle)))
                    context.fill(disc(center.x,center.y,0.070), with: .color(.black))
                } else {
                    blade.move(to: q(0.43,0))
                    blade.addQuadCurve(to: q(0.08,0.15), control: q(0.36,0.26))
                    blade.addQuadCurve(to: q(0.10,-0.04), control: q(0.025,0.06))
                    blade.addQuadCurve(to: q(0.43,0), control: q(0.28,0.08))
                    blade.closeSubpath()
                }
                context.fill(blade, with: .color(.black))
            }
            context.fill(disc(0.5,0.5,0.115), with: .color(.black))
        }
        .aspectRatio(1, contentMode: .fit)
        .accessibilityLabel(mode.title)
    }
}
