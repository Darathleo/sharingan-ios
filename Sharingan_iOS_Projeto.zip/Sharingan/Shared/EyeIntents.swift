import ActivityKit
import AppIntents

struct ChangeEyeIntent: LiveActivityIntent {
    static var title: LocalizedStringResource = "Alternar Sharingan"
    static var openAppWhenRun: Bool = false

    func perform() async throws -> some IntentResult {
        for activity in Activity<EyeAttributes>.activities where activity.activityState == .active || activity.activityState == .stale {
            let mode = activity.content.state.mode.next
            await activity.update(ActivityContent(state: EyeAttributes.ContentState(mode: mode), staleDate: nil))
        }
        return .result()
    }
}

struct EndEyeIntent: LiveActivityIntent {
    static var title: LocalizedStringResource = "Desativar Sharingan"
    static var openAppWhenRun: Bool = false

    func perform() async throws -> some IntentResult {
        for activity in Activity<EyeAttributes>.activities {
            await activity.end(nil, dismissalPolicy: .immediate)
        }
        return .result()
    }
}
