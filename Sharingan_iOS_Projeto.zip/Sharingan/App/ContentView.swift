import SwiftUI
import ActivityKit

struct ContentView: View {
    @Environment(\.scenePhase) private var scenePhase
    @AppStorage("preferredEye") private var preference: String = EyeMode.classic.rawValue
    @State private var activity: Activity<EyeAttributes>?
    @State private var mode: EyeMode = .classic
    @State private var busy = false
    @State private var error: String?
    private let accent = Color(red: 0.86, green: 0.10, blue: 0.20)

    var body: some View {
        ScrollView {
            VStack(spacing: 25) {
                VStack(spacing: 7) {
                    Text("SHARINGAN").font(.system(size: 12, weight: .semibold, design: .monospaced)).tracking(6).foregroundStyle(accent)
                    Text("Dynamic Island").font(.system(size: 30, weight: .medium)).foregroundStyle(.white)
                    Text("Seu olho. Seu modo.").font(.subheadline).foregroundStyle(.secondary)
                }
                HStack(spacing: 0) {
                    EyeMark(mode: mode).frame(width: 23, height: 23)
                    Spacer(minLength: 8)
                    Capsule().fill(.black).frame(width: 105, height: 29)
                    Spacer(minLength: 8)
                    Circle().fill(accent.opacity(0.65)).frame(width: 5, height: 5)
                }
                .padding(.horizontal, 12).frame(width: 184, height: 40)
                .background(.black, in: Capsule())
                .overlay(Capsule().strokeBorder(.white.opacity(0.12)))
                .accessibilityLabel("Prévia ilustrativa da Dynamic Island")
                EyeMark(mode: mode).frame(width: 104, height: 104).padding(20)
                HStack(spacing: 9) {
                    ForEach(EyeMode.allCases) { choice in
                        Button {
                            Task { await select(choice) }
                        } label: {
                            VStack(spacing: 10) {
                                EyeMark(mode: choice).frame(width: 29, height: 29)
                                Text(choice.title).font(.caption2.weight(.medium)).lineLimit(1).minimumScaleFactor(0.7)
                            }
                            .frame(maxWidth: .infinity).padding(.vertical, 13)
                            .background(Color.white.opacity(0.045), in: RoundedRectangle(cornerRadius: 15))
                            .overlay(RoundedRectangle(cornerRadius: 15).strokeBorder(mode == choice ? accent : .white.opacity(0.08)))
                        }
                        .buttonStyle(.plain).disabled(busy)
                        .accessibilityAddTraits(mode == choice ? [.isSelected] : [])
                    }
                }
                HStack(spacing: 7) {
                    Circle().fill(activity == nil ? Color.gray : accent).frame(width: 7, height: 7)
                    Text(activity == nil ? "Sessão inativa" : "Sessão ativa").font(.footnote).foregroundStyle(.secondary)
                }
                Button {
                    Task { if activity == nil { await start() } else { await stop() } }
                } label: {
                    Text(activity == nil ? "Ativar Sharingan" : "Desativar Sharingan")
                        .font(.headline).frame(maxWidth: .infinity).padding(16)
                        .background(activity == nil ? accent : Color.white.opacity(0.10), in: RoundedRectangle(cornerRadius: 16))
                        .foregroundStyle(.white)
                }
                .buttonStyle(.plain).disabled(busy)
                if let error {
                    Text(error).font(.footnote).foregroundStyle(.orange).multilineTextAlignment(.center)
                }
                Text("Após ativar, volte à tela inicial. Mantenha a ilha pressionada para alternar o olho ou encerrar a sessão.")
                    .font(.footnote).foregroundStyle(.secondary).multilineTextAlignment(.center)
            }
            .padding(24).padding(.top, 30).frame(maxWidth: 440)
            .frame(maxWidth: .infinity)
        }
        .background(Color(red: 0.045, green: 0.045, blue: 0.055).ignoresSafeArea())
        .onAppear { refresh() }
        .onChange(of: scenePhase) { _, phase in if phase == .active { refresh() } }
        .task(id: activity?.id) {
            guard let observed = activity else { return }
            for await content in observed.contentUpdates {
                guard activity?.id == observed.id else { break }
                mode = content.state.mode
                preference = mode.rawValue
            }
        }
        .task(id: activity?.id) {
            guard let observed = activity else { return }
            for await state in observed.activityStateUpdates {
                if state == .ended || state == .dismissed { refresh(); break }
            }
        }
    }

    @MainActor private func refresh() {
        activity = Activity<EyeAttributes>.activities.first { $0.activityState == .active || $0.activityState == .stale }
        mode = activity?.content.state.mode ?? EyeMode(rawValue: preference) ?? .classic
    }

    @MainActor private func select(_ choice: EyeMode) async {
        guard !busy else { return }
        busy = true; defer { busy = false }
        error = nil; mode = choice; preference = choice.rawValue
        if let activity {
            await activity.update(ActivityContent(state: EyeAttributes.ContentState(mode: choice), staleDate: nil))
        }
        refresh()
    }

    @MainActor private func start() async {
        guard !busy else { return }
        busy = true; defer { busy = false }
        error = nil
        guard ActivityAuthorizationInfo().areActivitiesEnabled else {
            error = "Ative as Atividades ao Vivo nos Ajustes do iPhone para este app."
            return
        }
        refresh()
        if activity != nil { return }
        do {
            activity = try Activity.request(attributes: EyeAttributes(startedAt: .now), content: ActivityContent(state: EyeAttributes.ContentState(mode: mode), staleDate: nil), pushType: nil)
        } catch {
            self.error = "Não foi possível iniciar: \(error.localizedDescription)"
        }
    }

    @MainActor private func stop() async {
        guard !busy else { return }
        busy = true; defer { busy = false }
        for item in Activity<EyeAttributes>.activities {
            await item.end(nil, dismissalPolicy: .immediate)
        }
        refresh()
    }
}
