import SwiftUI
import WidgetKit
import ActivityKit
import AppIntents

@main
struct EyeWidget: Widget {
    private let accent = Color(red: 0.86, green: 0.10, blue: 0.20)

    var body: some WidgetConfiguration {
        ActivityConfiguration(for: EyeAttributes.self) { context in
            HStack(spacing: 14) {
                EyeMark(mode: context.state.mode).frame(width: 38, height: 38)
                VStack(alignment: .leading, spacing: 4) {
                    Text(context.state.mode.title).font(.headline)
                    Text("Sessão visual ativa").font(.caption).foregroundStyle(.secondary)
                    Text(context.attributes.startedAt, style: .timer).font(.caption2.monospacedDigit()).foregroundStyle(.secondary)
                }
                Spacer(minLength: 3)
                controls
            }
            .padding(15)
            .activityBackgroundTint(.black)
            .activitySystemActionForegroundColor(.white)
            .foregroundStyle(.white)
        } dynamicIsland: { context in
            DynamicIsland {
                DynamicIslandExpandedRegion(.leading) {
                    EyeMark(mode: context.state.mode).frame(width: 30, height: 30).padding(.leading, 5)
                }
                DynamicIslandExpandedRegion(.trailing) {
                    Circle().fill(accent).frame(width: 6, height: 6).padding(.trailing, 10)
                }
                DynamicIslandExpandedRegion(.bottom) {
                    HStack {
                        VStack(alignment: .leading, spacing: 3) {
                            Text(context.state.mode.title).font(.caption.weight(.semibold))
                            Text("Sessão visual").font(.caption2).foregroundStyle(.secondary)
                        }
                        Spacer()
                        controls
                    }.padding(.horizontal, 10).padding(.bottom, 6)
                }
            } compactLeading: {
                EyeMark(mode: context.state.mode).frame(width: 22, height: 22).accessibilityLabel(context.state.mode.title)
            } compactTrailing: {
                Circle().fill(accent.opacity(0.7)).frame(width: 5, height: 5).padding(.trailing, 3).accessibilityLabel("Sessão ativa")
            } minimal: {
                EyeMark(mode: context.state.mode).frame(width: 19, height: 19)
            }
            .keylineTint(accent.opacity(0.6))
        }
    }

    private var controls: some View {
        HStack(spacing: 9) {
            Button(intent: ChangeEyeIntent()) {
                Image(systemName: "arrow.triangle.2.circlepath").font(.system(size: 15, weight: .semibold))
                    .frame(width: 38, height: 38).background(.white.opacity(0.13), in: Circle())
            }.buttonStyle(.plain).foregroundStyle(.white).accessibilityLabel("Alternar olho")
            Button(intent: EndEyeIntent()) {
                Image(systemName: "power").font(.system(size: 15, weight: .semibold))
                    .frame(width: 38, height: 38).background(accent.opacity(0.24), in: Circle())
            }.buttonStyle(.plain).foregroundStyle(accent).accessibilityLabel("Desativar Sharingan")
        }
    }
}
