# Sharingan — Dynamic Island (protótipo 1.0)

Aplicativo iOS pessoal, local e offline. O olho é desenhado em SwiftUI: 22 pt no modo compacto, 19 pt no modo mínimo. Não há animação periódica, servidor, notificações push ou coleta de dados. O iOS controla as dimensões da ilha.

## Instalar no iPhone
1. Em um Mac, instale uma versão do Xcode compatível com a versão do iOS do aparelho. O projeto tem deployment target iOS 17.0 e requer um iPhone com Dynamic Island para a experiência proposta.
2. Abra `Sharingan.xcodeproj` no Xcode. Faça login em Xcode > Settings > Apple Accounts.
3. Selecione o projeto Sharingan na barra esquerda, depois o target **Sharingan** > Signing & Capabilities. Ative Automatically manage signing e selecione sua Personal Team ou equipe paga.
4. Escolha um Bundle Identifier único, por exemplo `com.seunome.sharingan` (use seu identificador real). No target **SharinganWidget**, selecione a mesma equipe e um Bundle Identifier com o mesmo prefixo, por exemplo `com.seunome.sharingan.widget`. Não adicione Push Notifications nem grupos de apps.
5. Conecte o iPhone via cabo, desbloqueie, confirme Confiar e, se solicitado, ative Modo de Desenvolvedor em Ajustes > Privacidade e Segurança. Reinicie e confirme o modo se o iOS pedir.
6. Selecione o esquema Sharingan e o iPhone como destino na barra superior do Xcode; pressione Cmd+R. O Xcode fará a assinatura e a instalação. Uma conta gratuita exige reaprovisionamento periódico (normalmente sete dias).
7. No app, escolha Sharingan, Mangekyō ou Fechado. Toque Ativar Sharingan e volte à tela inicial. Para trocar o olho sem abrir o app, mantenha a Dynamic Island pressionada e toque no botão de alternância. O botão de energia encerra a atividade. Um toque simples na ilha abre o app, conforme o sistema.

## Teste rápido
- Ativar e voltar à tela inicial: íris compacta à esquerda, ponto discreto à direita, conforme layout escolhido pelo iOS.
- Abrir outro aplicativo: verificar se a atividade permanece visível; outras atividades podem alterar sua apresentação.
- Pressionar e segurar a ilha: alternar os três estados, depois desativar. Conferir também a tela bloqueada.
- Reabrir o app: ele deve refletir a atividade atual; ativar novamente não deve duplicar uma sessão existente.
- Se não aparecer: conferir se Atividades ao Vivo estão habilitadas para o app nos Ajustes, se o iPhone tem Dynamic Island e se o target Widget foi embutido e assinado.

## Limitações e validação
- É uma Live Activity, não uma modificação do sistema nem um wallpaper permanente. O iOS pode priorizar outra atividade, mudar o modo de exibição ou encerrar a sessão. O limite usual de uma Live Activity é oito horas; é necessário reativar manualmente. O ponto da direita mantém uma apresentação compacta de dois lados.
- AppIntents fornecem os botões no modo expandido e na tela bloqueada; a apresentação compacta não oferece botões independentes.
- É um protótipo de uso pessoal, não revisado para a App Store. A Apple espera Live Activities ligadas a uma atividade real; publicação e uso de marcas de terceiros exigem avaliação separada.
- Os arquivos Swift foram validados sintaticamente com o compilador Swift em Linux e os plists foram validados. Não foi possível compilar contra o SDK iOS, assinar ou testar em hardware Apple neste ambiente. A primeira compilação e a validação no aparelho ainda são necessárias. Nenhum IPA pré-assinado está incluído.

## Referências Apple
- https://developer.apple.com/documentation/activitykit/displaying-live-data-with-live-activities
- https://developer.apple.com/documentation/widgetkit/adding-interactivity-to-widgets-and-live-activities
- https://developer.apple.com/help/account/basics/about-your-developer-account/
- https://developer.apple.com/documentation/xcode/running-your-app-on-simulated-or-physical-devices
